#!/bin/sh
##############################################################################
# Copyright (c) 2013-14: fritz-hh from Github (https://github.com/fritz-hh)
##############################################################################

echo "This script is deprecated. Use 'ocrmypdf' instead."

python3 -m ocrmypdf.main "$@"
