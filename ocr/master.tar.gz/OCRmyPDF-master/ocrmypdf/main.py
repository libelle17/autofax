#!/usr/bin/env python3
# © 2015-16 James R. Barlow: github.com/jbarlow83

# This file is now an alias for __main__
# Consider removing in future releases

from ocrmypdf.__main__ import *
