#!/usr/bin/env python3
import sys


def main():
    print('qpdf dummy')
    sys.exit(2)


if __name__ == '__main__':
    main()
